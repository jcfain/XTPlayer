#include <portaudio.h>

int main()
{
	return 0;
}