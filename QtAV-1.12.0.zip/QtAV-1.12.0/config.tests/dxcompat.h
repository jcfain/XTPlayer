#include "../src/directx/dxcompat.h"
//#include <windows.h> //to include _mingw.h
// check __MINGW64_VERSION_MAJOR? 5.x has complete headers we need
