<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="5"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="22"/>
        <source>based on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="23"/>
        <source>QtAV is a cross platform, high performance multimedia framework</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="26"/>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="27"/>
        <source>Install QtAV for Windows desktop/store, macOS, Linux and Android</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="28"/>
        <source>Double click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="28"/>
        <source>show/hide control bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="29"/>
        <source>Click right area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="29"/>
        <source>show config panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="30"/>
        <location filename="../qml/QMLPlayer/About.qml" line="31"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="30"/>
        <source>a subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="30"/>
        <source>press open button to select a subtitle, or a video + a subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="31"/>
        <source>a URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="31"/>
        <source>press and hold open button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="34"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="35"/>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="35"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="35"/>
        <source>Up/Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="35"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="36"/>
        <source>Left/Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="36"/>
        <source>Swipe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="36"/>
        <source>Seek backward/forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="37"/>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="37"/>
        <source>Pause/Resume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="37"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="38"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="38"/>
        <source>Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/About.qml" line="42"/>
        <source>Donate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioPage</name>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="8"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="27"/>
        <source>Channel layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="47"/>
        <source>Audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="70"/>
        <source>External</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="89"/>
        <source>Click here to select a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="100"/>
        <source>Stereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="101"/>
        <source>Mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="102"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="103"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/AudioPage.qml" line="128"/>
        <source>Open an external audio track</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigPanel</name>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="33"/>
        <source>Media info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="34"/>
        <source>Video codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="35"/>
        <source>Effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="36"/>
        <source>Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="37"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="38"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/ConfigPanel.qml" line="39"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectPage</name>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="6"/>
        <source>Effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="27"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="50"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="73"/>
        <source>Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="96"/>
        <source>Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/EffectPage.qml" line="116"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MediaInfoPage</name>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="6"/>
        <source>Media Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="28"/>
        <source>Duration: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="34"/>
        <source>Size: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="36"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="38"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="40"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="42"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="44"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="46"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="48"/>
        <source>Publisher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="50"/>
        <source>Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="52"/>
        <source>Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="54"/>
        <source>Track count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="57"/>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="58"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="59"/>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="70"/>
        <source>Bit rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="60"/>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="66"/>
        <source>Codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="61"/>
        <source>Pixel format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="62"/>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="62"/>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="65"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="67"/>
        <source>Sample format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="68"/>
        <source>Sample rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MediaInfoPage.qml" line="69"/>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MiscPage</name>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="5"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="15"/>
        <source>Reset all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="25"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="42"/>
        <source>Press on the preview item to seek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="64"/>
        <source>Requirement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="81"/>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="201"/>
        <source>Restart to apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="162"/>
        <source>Developer only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/MiscPage.qml" line="201"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListPanel</name>
    <message>
        <location filename="../qml/QMLPlayer/PlayListPanel.qml" line="58"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubtitlePage</name>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="7"/>
        <source>Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="27"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="27"/>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="51"/>
        <source>Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="79"/>
        <source>Supported formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="102"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="115"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="130"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="174"/>
        <source>Font file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="182"/>
        <source>Force</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="192"/>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="223"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="215"/>
        <source>Fonts dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="241"/>
        <source>Embedded Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="271"/>
        <source>External Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="284"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="293"/>
        <source>Auto load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="325"/>
        <source>Choose a font file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/SubtitlePage.qml" line="332"/>
        <source>Choose a fonts dir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoCodec</name>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="6"/>
        <source>Video Codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="13"/>
        <source>Takes effect on the next play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="75"/>
        <source>hardware decoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="75"/>
        <source>software decoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="80"/>
        <source>Zero Copy support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/VideoCodec.qml" line="88"/>
        <source>Zero copy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/QMLPlayer/main.qml" line="196"/>
        <source>Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/QMLPlayer/main.qml" line="571"/>
        <source>Open a URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
