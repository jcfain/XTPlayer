/******************************************************************************
    QtAV:  Multimedia framework based on Qt and FFmpeg
    Copyright (C) 2012-2016 Wang Bin <wbsecg1@gmail.com>

*   This file is part of QtAV (from 2013)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
******************************************************************************/

#include "filter/FilterManager.h"
#include <QtCore/QMap>
#include "QtAV/AVPlayer.h"
#include "QtAV/Filter.h"
#include "QtAV/AVOutput.h"
#include "utils/Logger.h"

namespace QtAV {

class FilterManagerPrivate : public DPtrPrivate<FilterManager>
{
public:
    FilterManagerPrivate()
    {}
    ~FilterManagerPrivate() {
    }

    QList<Filter*> pending_release_filters;
    QMap<AVOutput*, QList<Filter*> > filter_out_map;
    QMap<AVPlayer*, QList<Filter*> > afilter_player_map;
    QMap<AVPlayer*, QList<Filter*> > vfilter_player_map;
};

FilterManager::FilterManager()
{
}

FilterManager::~FilterManager()
{
}

FilterManager& FilterManager::instance()
{
    static FilterManager sMgr;
    return sMgr;
}

bool FilterManager::insert(Filter *filter, QList<Filter *> &filters, int pos)
{
    int p = pos;
    if (p < 0)
        p += filters.size();
    if (p < 0)
        p = 0;
    if (p > filters.size())
        p = filters.size();
    const int index = filters.indexOf(filter);
    // already installed at desired position
    if (p == index)
        return false;
    if (p >= 0)
        filters.removeAt(p);
    filters.insert(p, filter);
    return true;
}

bool FilterManager::registerFilter(Filter *filter, AVOutput *output, int pos)
{
    DPTR_D(FilterManager);
    d.pending_release_filters.removeAll(filter); //erase?
    QList<Filter*>& fs = d.filter_out_map[output];
    return insert(filter, fs, pos);
}

QList<Filter*> FilterManager::outputFilters(AVOutput *output) const
{
    DPTR_D(const FilterManager);
    return d.filter_out_map.value(output);
}

bool FilterManager::registerAudioFilter(Filter *filter, AVPlayer *player, int pos)
{
    DPTR_D(FilterManager);
    d.pending_release_filters.removeAll(filter); //erase?
    QList<Filter*>& fs = d.afilter_player_map[player];
    return insert(filter, fs, pos);
}

QList<Filter*> FilterManager::audioFilters(AVPlayer *player) const
{
    DPTR_D(const FilterManager);
    return d.afilter_player_map.value(player);
}

bool FilterManager::registerVideoFilter(Filter *filter, AVPlayer *player, int pos)
{
    DPTR_D(FilterManager);
    d.pending_release_filters.removeAll(filter); //erase?
    QList<Filter*>& fs = d.vfilter_player_map[player];
    return insert(filter, fs, pos);
}

QList<Filter *> FilterManager::videoFilters(AVPlayer *player) const
{
    DPTR_D(const FilterManager);
    return d.vfilter_player_map.value(player);
}

// called by AVOutput/AVPlayer.uninstall imediatly
bool FilterManager::unregisterAudioFilter(Filter *filter, AVPlayer *player)
{
    DPTR_D(FilterManager);
    QList<Filter*>& fs = d.afilter_player_map[player];
    if (fs.removeAll(filter) > 0) {
        if (fs.isEmpty())
            d.afilter_player_map.remove(player);
        return true;
    }
    return false;
}

bool FilterManager::unregisterVideoFilter(Filter *filter, AVPlayer *player)
{
    DPTR_D(FilterManager);
    QList<Filter*>& fs = d.vfilter_player_map[player];
    if (fs.removeAll(filter) > 0) {
        if (fs.isEmpty())
            d.vfilter_player_map.remove(player);
        return true;
    }
    return false;
}

bool FilterManager::unregisterFilter(Filter *filter, AVOutput *output)
{
    DPTR_D(FilterManager);
    QList<Filter*>& fs = d.filter_out_map[output];
    return fs.removeAll(filter) > 0;
}

bool FilterManager::uninstallFilter(Filter *filter)
{
    DPTR_D(FilterManager);
    QMap<AVPlayer*, QList<Filter*> >::iterator it = d.vfilter_player_map.begin();
    while (it != d.vfilter_player_map.end()) {
        if (uninstallVideoFilter(filter, it.key()))
            return true;
        ++it;
    }
    it = d.afilter_player_map.begin();
    while (it != d.afilter_player_map.end()) {
        if (uninstallAudioFilter(filter, it.key()))
            return true;
        ++it;
    }
    QMap<AVOutput*, QList<Filter*> >::iterator it2 = d.filter_out_map.begin();
    while (it2 != d.filter_out_map.end()) {
        if (uninstallFilter(filter, it2.key()))
            return true;
        ++it2;
    }
    return false;
}

bool FilterManager::uninstallAudioFilter(Filter *filter, AVPlayer *player)
{
    if (unregisterAudioFilter(filter, player))
        return player->uninstallFilter(reinterpret_cast<AudioFilter*>(filter));
    return false;
}

bool FilterManager::uninstallVideoFilter(Filter *filter, AVPlayer *player)
{
    if (unregisterVideoFilter(filter, player))
        return player->uninstallFilter(reinterpret_cast<VideoFilter*>(filter));
    return false;
}

bool FilterManager::uninstallFilter(Filter *filter, AVOutput *output)
{
    if (unregisterFilter(filter, output))
        return output->uninstallFilter(filter);
    return false;
}
} //namespace QtAV
